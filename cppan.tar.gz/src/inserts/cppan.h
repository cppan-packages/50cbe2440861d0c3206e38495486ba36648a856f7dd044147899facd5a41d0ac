// This file is in public domain.

// C++ Archive Network (CPPAN)

#pragma once

/*******************************************************************************
*
* general
*
******************************************************************************/

#ifndef CPPAN_BUILD
#define CPPAN_BUILD
#endif

#ifndef CPPAN_CONFIG
#define CPPAN_CONFIG ""
#endif

#ifndef CPPAN_EXPORT
#define CPPAN_EXPORT
#endif

#ifndef CPPAN_PROLOG
#define CPPAN_PROLOG
#endif

#ifndef CPPAN_EPILOG
#define CPPAN_EPILOG
#endif

/******************************************************************************/
